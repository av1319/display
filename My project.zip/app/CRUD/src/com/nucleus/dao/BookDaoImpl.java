package com.nucleus.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.nucleus.domain.Book;
import com.nucleus.connection.CreateConnection;;

public class BookDaoImpl implements BookDAO{
	
	public void insertBook(Book book){
		CreateConnection createConnection = new CreateConnection();
		Connection conn = createConnection.ConnectionClass();
		
		PreparedStatement pstmt;
		try {
			pstmt = conn.prepareStatement("insert into book0 values(?,?,?)");
			pstmt.setInt(1,book.getBookId() );
			pstmt.setString(2, book.getBookName());
			pstmt.setFloat(3,book.getPrice());
			pstmt.executeUpdate();
			System.out.println("saved");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	public Book getBookByBookId(int bookId){
		CreateConnection createConnection = new CreateConnection();
		Connection conn = createConnection.ConnectionClass();
		PreparedStatement pstmt;
		ResultSet resultSet;
		Book book= new Book();
		
		try {
			pstmt = conn.prepareStatement("Select * from book121 where bid =? ");
			pstmt.setInt(1,bookId);
			resultSet = pstmt.executeQuery();
			
			if(resultSet.next()){
		book.setBookId(resultSet.getInt(1));		
		book.setBookName(resultSet.getString(2));		
		book.setPrice(resultSet.getFloat(3));		
			}
		}
		 catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		
		return book;
	}
		
		
	public Book deleteBook(int bookId){
		CreateConnection createConnection = new CreateConnection();
		Connection conn = createConnection.ConnectionClass();
		PreparedStatement pstmt;
		ResultSet resultSet;
		Book book= new Book();
		try {
			
			pstmt = conn.prepareStatement("delete from book121 where bid=?");
			pstmt.setInt(1,bookId);
			pstmt.executeUpdate();
			
			
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return book;
	}
	public Book updateBook(int bookId,String bookTitle){
		CreateConnection createConnection = new CreateConnection();
		Connection conn = createConnection.ConnectionClass();
		PreparedStatement pstmt;
		ResultSet resultSet;
		Book book= new Book();
		
		try {
			pstmt = conn.prepareStatement("update book121 set btitle=? where bid=?");
			pstmt.setString(1,bookTitle);
			pstmt.setInt(2,bookId);
			pstmt.executeUpdate();
			System.out.println("---------Updated----------");
		} catch (SQLException e) {
	
			e.printStackTrace();
		}
		return book;
	}

}
