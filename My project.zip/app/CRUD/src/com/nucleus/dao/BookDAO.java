package com.nucleus.dao;
import com.nucleus.domain.Book;


public interface BookDAO {
	public void insertBook(Book book);
	public Book getBookByBookId(int bookId);
	public Book deleteBook(int bookId);
	public Book updateBook(int bookId,String bookTitle);
	
}
