package execution;
import java.util.Scanner;
import com.nucleus.dao.BookDAO;
import com.nucleus.dao.BookDaoImpl;
import com.nucleus.domain.Book;
public class Execution {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int ch;
		int id;
		String name;
		float price;
		Book book=null;
		BookDAO bookDao  = new	BookDaoImpl (); 
		do {
			System.out
					.println("Enter 1 to insert \n2 to display\n3 to delete \n4 to update");
			ch = s.nextInt();
			switch (ch) {
			case 1:
				System.out.println("Enter the id to insert");
				 id= s.nextInt();
				System.out.println("Enter the name to insert");
				 name= s.next();
				System.out.println("Enter the price to insert");
				 price = s.nextFloat();
				bookDao.insertBook(book);
				break;
				
			case 2:
				System.out.println("Enter the id to insert");
				id= s.nextInt();
				Book b=bookDao.getBookByBookId(id);
				System.out.println(b);
				break;
			case 3:
				System.out.println("Enter the id to delete");
				id= s.nextInt();
				Book boo=bookDao.deleteBook(id);
				System.out.println("deleted: "+id);
				break;
			case 4:
				System.out.println("Enter the id to update");
				id= s.nextInt();
				System.out.println("Enter the the new name");
				name= s.next();
				Book bb=bookDao.updateBook(id, name);
				break;
			default:System.out.println("You have entered a wrong choice");
				break;
			}

		} while (ch == 1||ch==2||ch==3||ch==4);
		s.close();
	}

}
