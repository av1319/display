package com.nucleus.domain;

public class CustomerM {
	
	//All the Variables used in this program
	private int customerID;
	private String customerCode;
	private String customerName;
	private String customerAdd1;
	private String customerAdd2;
	private long customerPinCode;
	private String emailAdd;
	private long contact_Number;
	private String primaryContactPerson;
	private String recordStatus;
	private String flag;
	private String createDate;
	private String createdBy;
	private String modifiedDate;
	private String modifiedBy;
	private String authorisedDate;
	private String authorisedBy;

	//**************GETTERS AND SETTERS**************************************
	public int getCustomerID() {
		return customerID;
	}

	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}

	public String getCustomerCode() {
		return customerCode;
	}

	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerAdd1() {
		return customerAdd1;
	}

	public void setCustomerAdd1(String customerAdd1) {
		this.customerAdd1 = customerAdd1;
	}

	public String getCustomerAdd2() {
		return customerAdd2;
	}

	public void setCustomerAdd2(String customerAdd2) {
		this.customerAdd2 = customerAdd2;
	}

	public long getCustomerPinCode() {
		return customerPinCode;
	}

	public void setCustomerPinCode(long customerPinCode) {
		this.customerPinCode = customerPinCode;
	}

	public String getEmailAdd() {
		return emailAdd;
	}

	public void setEmailAdd(String emailAdd) {
		this.emailAdd = emailAdd;
	}

	public long getContact_Number() {
		return contact_Number;
	}

	public void setContact_Number(long contact_Number) {
		this.contact_Number = contact_Number;
	}

	public String getPrimaryContactPerson() {
		return primaryContactPerson;
	}

	public void setPrimaryContactPerson(String primaryContactPerson) {
		this.primaryContactPerson = primaryContactPerson;
	}

	public String getRecordStatus() {
		return recordStatus;
	}

	public void setRecordStatus(String recordStatus) {
		this.recordStatus = recordStatus;
	}

	public String getFlag() {
		return flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	public String getCreateDate() {
		return createDate;
	}

	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public String getAuthorisedDate() {
		return authorisedDate;
	}

	public void setAuthorisedDate(String authorisedDate) {
		this.authorisedDate = authorisedDate;
	}

	public String getAuthorisedBy() {
		return authorisedBy;
	}

	public void setAuthorisedBy(String authorisedBy) {
		this.authorisedBy = authorisedBy;
	}

	public String toString(){
		
		return "Customer code "+customerCode+"Customer name "+ customerName+"Customer Address1"+getCustomerAdd1()+"Customer Address1"
		+getCustomerAdd2()+"Customer PinCode"+getCustomerPinCode()+"Customer Email-Address"+getEmailAdd()+"Customer Contact Number"
		+getContact_Number()+"Customer Primary Contact person"+getPrimaryContactPerson() +"Record Status"+getRecordStatus() +"Flag"
		+getFlag()+"Created Date"+ getCreateDate()+"Created By"+getCreatedBy()+"Modified Date"+getModifiedDate()+"Modified By"
		+getModifiedBy()+"Authorised Date"+getAuthorisedDate()+"Authorised By"+getAuthorisedBy();
	}
}
