package com.nucleus.validation;

public class Length {

	
	public int fieldLength(Long pinCode){
		int count=0;
		Long r;
		while(pinCode>0){
			r=pinCode%10;
			pinCode=pinCode/10;
			count++;
			
		}
		
		return count;
		
	}
	
	
	
	
}
