package assignment1_day1;
import java.util.*;

public class Gradesaverage {

	public static void main(String[] args) {
 Scanner s = new Scanner(System.in);
 System.out.println("Enter the no. of students");
 int numStudents = s.nextInt();
 int sum=0;
 int arr1[] = new int[numStudents];
 
 for (int i = 0; i < numStudents; i++) {
	System.out.println("Enter the marks of student"+(i+1)+":");
	int marks=s.nextInt();
	if(marks>=0 && marks<=100){
		arr1[i]=marks;
		sum+=arr1[i];
	}
	else {
		
		System.out.println("Invalid grade, try again...");
		i--;
	}
	
}
float avg=sum/numStudents;
System.out.println("The average is "+avg);
	}

}

