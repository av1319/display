package assignment1_day4;
import java.util.*;
public abstract class PowerOverride {

	abstract void pow();
	
}

class calPow extends PowerOverride {
	
	double baseN;
	double powerN;
	
public calPow(double baseN, double powerN) {
		
		this.baseN = baseN;
		this.powerN = powerN;
	}

void pow()	{
	double c=1;
	
	for (int i = 0; i < powerN; i++) {
		c = baseN * c;
	}
	System.out.println("The Base Number: "+baseN+" is Raised to power: "+powerN+" is: "+c);
}

}

class TestPow{
	public static void main(String[] args) {
		double b;
		double p;
		int c;
		Scanner s= new Scanner(System.in);
		do {
			System.out.println("Enter Base number");
			b=s.nextDouble();
			System.out.println("Enter The number to which power should be raised  ");
			p=s.nextDouble();
			PowerOverride power= new calPow(b,p);
			power.pow();
			System.out.println("press 1 to continue");
			c=s.nextInt();
		} while (c==1);
		
	}
	
	
}