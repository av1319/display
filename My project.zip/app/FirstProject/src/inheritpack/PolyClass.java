package inheritpack;


class Account1{

	public void deposit(String type){
		System.out.println("The deposit for Parent has been made"+type+" and the min limit is $100");
	}
	
}

class Savings1 extends Account1{
	public void deposit(String type){
		System.out.println("The deposit for child has been made "+type+" and the ,min limit is $0");
	
	}
	

}
class Current1 extends Account1{
	public void deposit(String type){
	System.out.println("The deposit for child has been made "+type);
	}
	

}
public class PolyClass {
	
	public static void main(String[] args) {
		/*Account1 ac = new Savings1();
		ac.display(ac);
		ac=new Current1();
		ac.display(ac);*/
		Account1 ac=new Account1();
		PolyClass pa = new PolyClass();
		Savings1 sa = new Savings1();
		Current1 ca=new Current1();
		ac.deposit("Account");
		pa.display(sa);
		pa.display(ca);
		
	}
	public void display(Account1 ac){
		if(ac instanceof Savings1){
			
			Savings1 sa=(Savings1)ac;
			sa.deposit("Savings");
		}
		else if(ac instanceof Current1){
			Current1 ca=(Current1)ac;
			ca.deposit("Current");
		}
		
	}

}
