package assignment1_day3;
import java.util.*;
public class StudentHostle {

	private int studentID;
	private String name; 
	private int courseID;
	private String sex; 
	private int phoneNumber;
	public StudentHostle(int studentID, String name, int courseID, String sex,int phoneNumber)
	{
		
		this.studentID = studentID;
		this.name = name;
		this.courseID = courseID;
		this.sex = sex;
		this.phoneNumber = phoneNumber;
	}
	public int getStudentID() {
		return studentID;
	}
	
	public String getName() {
		return name;
	}
	
	public int getCourseID() {
		return courseID;
	}
	
	public String getSex() {
		return sex;
	}
	
	public int getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(int phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	
	
	
}
class Hosteller extends StudentHostle
{
	private String hostleName;
	private int roomNumber;
	public Hosteller(int studentID, String name, int courseID, String sex,int phoneNumber, String hostleName, int roomNumber) {
		super(studentID, name, courseID, sex, phoneNumber);
		this.hostleName = hostleName;
		this.roomNumber = roomNumber;
		
	}
	
	public String getHostleName() {
		return hostleName;
	}


	public int getRoomNumber() {
		return roomNumber;
	}
	public void setRoomNumber(int roomNumber) {
		this.roomNumber = roomNumber;
	}
	
	
	public void display(){
		
		System.out.println("Student id "+getStudentID()+"\nName "+getName()+"\nCourse id "+getCourseID()+"\nSex "+getSex()+"\n Phone Number "+getPhoneNumber()+"\nHostle Name "+getHostleName()+"\n Room Number"+getRoomNumber());
	}
	
}

class TestStudentHostle{
	
	public static void main(String[] args) {
	int studentID;
	String name; 
	int courseID;
	String sex; 
	int phoneNumber;
	String hostleName;
	 int roomNumber;
	 int c;
	Scanner s= new Scanner(System.in);
	System.out.println("enter student id");
     studentID=s.nextInt();
	System.out.println("enter name");
	name=s.next(); 
	System.out.println("enter Course id");
	courseID=s.nextInt();
	System.out.println("enter sex");
	sex=s.next(); 
    System.out.println("enter phone no.");
	phoneNumber=s.nextInt();
	System.out.println("enter hostle name");
	hostleName=s.next();
	System.out.println("enter room no");
	 roomNumber=s.nextInt();
	 
	 Hosteller h= null;
	
	 do {
		 System.out.println("Enter 1 to display\n 2 to modify room no and phone no.");
		 c=s.nextInt();
		 switch(c){
		 
		 case 1:
			 h=new Hosteller(studentID, name ,courseID,sex,phoneNumber,hostleName,roomNumber);
			 h.display();
			 break;
			 
		 case 2: 
			 System.out.println("Enter room no and phone no modify room no and phone no.");
			 roomNumber=s.nextInt();
			 phoneNumber=s.nextInt();
			 h.setRoomNumber(roomNumber);
			 h.setPhoneNumber(phoneNumber);
			 System.out.println("Your modified details are");
			 h.display();
		 }
		
	} while (c==1||c==2);
	 s.close();
	}
}