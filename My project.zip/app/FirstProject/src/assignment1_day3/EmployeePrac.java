package assignment1_day3;

import java.util.Scanner;

public class EmployeePrac {
	private int empID;
	private String name; 
	private int projectID;
	private String designation; 
	private int phoneNumber;
	public EmployeePrac(int empID, String name, int projectID,
			String designation, int phoneNumber) {
		this.empID = empID;
		this.name = name;
		this.projectID = projectID;
		this.designation = designation;
		this.phoneNumber = phoneNumber;
	}
	public int getEmpID() {
		return empID;
	}

	public String getName() {
		return name;
	}
	
	public int getProjectID() {
		return projectID;
	}
	
	public String getDesignation() {
		return designation;
	}

	public int getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(int phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	
	
	
}


class PracticeHead extends EmployeePrac{
	
	
	private String practiceName;
	private int noOfCustomers;
	public PracticeHead(int empID, String name, int projectID,String designation, int phoneNumber, String practiceName,int noOfCustomers) {
		super(empID, name, projectID, designation, phoneNumber);
		this.practiceName = practiceName;
		this.noOfCustomers = noOfCustomers;
	}
	public String getPracticeName() {
		return practiceName;
	}
	
	public int getNoOfCustomers() {
		return noOfCustomers;
	}
	public void setNoOfCustomers(int noOfCustomers) {
		this.noOfCustomers = noOfCustomers;
	}
	
public void display(){
		
		System.out.println("Employee id "+getEmpID()+"\nName "+getName()+"\nProject id "+getProjectID()+"\nDesignation "+getDesignation()+"\n Phone Number "+getPhoneNumber()+"\nPractice Name "+getPracticeName()+"\n Number of customers"+getNoOfCustomers());
	}
	
}



class TestEmployeePrac{
	
	public static void main(String[] args) {
	int empID;
	String name; 
	int projectID;
	String designation; 
	int phoneNumber;
	String practiceName;
	 int noOfCustomers;
	 int c;
	Scanner s= new Scanner(System.in);
	System.out.println("enter employee id");
     empID=s.nextInt();
	System.out.println("enter name");
	name=s.next(); 
	System.out.println("enter project id");
	projectID=s.nextInt();
	System.out.println("enter designation");
	designation=s.next(); 
    System.out.println("enter phone no.");
	phoneNumber=s.nextInt();
	System.out.println("enter practice name");
	practiceName=s.next();
	System.out.println("enter  no of customers");
	 noOfCustomers=s.nextInt();
	 
	 PracticeHead ph= null;
	
	 do {
		 System.out.println("Enter 1 to display\n 2 to modify Number of customers and phone no.");
		 c=s.nextInt();
		 switch(c){
		 
		 case 1:
			 ph=new PracticeHead(empID, name ,projectID,designation,phoneNumber,practiceName,noOfCustomers);
			 ph.display();
			 break;
			 
		 case 2: 
			 System.out.println("Enter to modify no of customers and phone no ");
			 noOfCustomers=s.nextInt();
			 phoneNumber=s.nextInt();
			 ph.setNoOfCustomers(noOfCustomers);
			 ph.setPhoneNumber(phoneNumber);
			 System.out.println("Your modified details are");
			 ph.display();
		 }
		
	} while (c==1||c==2);
	 s.close();
	}
}