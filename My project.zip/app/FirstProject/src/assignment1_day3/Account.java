package assignment1_day3;

import java.util.Scanner;
import java.util.Random;

public class Account {
	private String customerName;
	private String accountNo;
	private String type_of_account;
	private double accountBalance;

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public String getType_of_account() {
		return type_of_account;
	}

	public void setType_of_account(String type_of_account) {
		this.type_of_account = type_of_account;
	}

	public double getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}

	void deposit(double amount) {
		accountBalance += amount;
		System.out.println("Your amount has been deposited");
	}

	double withdraw(double amount) {
		if (accountBalance > amount) {
			accountBalance = accountBalance - amount;
		} else {
			System.out.println(" Your account has less balance");
		}
		return accountBalance;
	}

	String  random1() {
		Random rand = new Random();
		accountNo = "" + rand.nextInt(10) + rand.nextInt(10) + rand.nextInt(10)
				+ rand.nextInt(10) + rand.nextInt(10);
		return accountNo;
	}
}

class SavingAccount extends Account {
	double calculateInterest(){
		double accountBalance = super.getAccountBalance();
		double r=5;
		double t=5;
		double n=0.25;
		double amount=accountBalance*(Math.pow(1+(r/n) ,(n*t) ));
		return amount;
	}

	public void display() {
		double compInterest = calculateInterest();
		double accountBalance = super.getAccountBalance();
		accountBalance = accountBalance + compInterest;;
		System.out.println(accountBalance);
	}
}

class CurrentAccount extends Account {
	double minBalance = 5000;
	boolean chequefacility = true;

	public void display() {
		double accountBalance = super.getAccountBalance();
		if (accountBalance < minBalance) {
			accountBalance -= (accountBalance * 1.5) / 100;
		}
		System.out.println("The penalty is"+ (accountBalance * 1.5) / 100+"Your account balance is" + accountBalance);

	}

}

class Bank {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.println("Welcome ");
		System.out.println("Enter your name");
		String name = sc.next();
		System.out
				.println("Enter the initial amount you want to deposit in your account ");
		double initialbalance = sc.nextDouble();

		System.out
				.println("What type of account do you want to open?\n 1. Saving Account \n 2. Current Account");
		int x = sc.nextInt();
		int y;
		do {
			switch (x) {
			case 1:
				SavingAccount sa = new SavingAccount();
				sa.setAccountBalance(initialbalance);
				sa.setCustomerName(name);
				sa.setType_of_account("Saving Account");
				String ac=sa.random1();
				System.out.println("Congrats! " + name+ " Your account has been created \n your account Number is "+ac);
				do {
					System.out.println("Enter '1' to deposit money");
					System.out.println("Enter '2' to withdraw money");
					System.out.println("Enter '3' to display current balance");
					y = sc.nextInt();
					switch (y) {
					case 1:
						System.out
								.println("Enter the amount you want to deposit");
						double amount = sc.nextDouble();
						sa.deposit(amount);
						break;
					case 2:
						System.out
								.println("Enter the amount you want to withdraw");
						amount = sc.nextDouble();
						sa.withdraw(amount);
						break;
					case 3:
						sa.display();
						break;

					}
				} while (y == 1 || y == 2 || y == 3);
				System.exit(0);
				break;
			case 2:
				CurrentAccount ca = new CurrentAccount();
				ca.setAccountBalance(initialbalance);
				ca.setCustomerName(name);
				ca.setType_of_account("Current Account");
				ca.random1();
				System.out.println("Congrats! " + name
						+ " Your account has been created ");
				do {
					System.out.println("Enter '1' to deposit money");
					System.out.println("Enter '2' to withdraw money");
					System.out.println("Enter '3' to display current balance");
					y = sc.nextInt();
					switch (y) {
					case 1:
						System.out
								.println("Enter the amount you want to deposit");
						double amount = sc.nextDouble();
						ca.deposit(amount);
						break;
					case 2:
						System.out
								.println("Enter the amount you want to withdraw");
						amount = sc.nextDouble();
						ca.withdraw(amount);
						break;
					case 3:
						ca.display();
						break;

					}
				} while (y == 1 || y == 2 || y == 3);
				System.exit(0);
				break;
			case 3:
				System.exit(0);
			default:
				System.out.println("Enter valid choice");

			}
		} while (x == 1 || x == 2);

	}

}
