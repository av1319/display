package pack1;

import java.util.Scanner;

public class Aggreclass {
	String Name="Akash";
//	ExamSchedule eschedule;
	
	
	public void displayDetails(ExamSchedule ex){
	//	eschedule = new ExamSchedule();
		System.out.println("Name: "+Name+"\nCourse id for Exam: "+ ex.getCourse_id()+"\nSubject name for exam "+ex.getSubject_name());
	}
	
	
	public static void main(String[] args) {
		
		Aggreclass Ag = new Aggreclass();
//		Ag.displayDetails();
		Scanner sc= new Scanner(System.in);
		
		System.out.println("Enter Course id and Course name");
		
		int Course_id=sc.nextInt();
		String Subject_name=sc.next();
		
		ExamSchedule ex = new ExamSchedule();
		
		ex.setCourse_id(Course_id);
		ex.setSubject_name(Subject_name);
		Ag.displayDetails(ex);
	}
}
class ExamSchedule{
	
	private int Course_id;
	private String Subject_name;
	
	public int getCourse_id() {
		return Course_id;
	}
	public void setCourse_id(int course_id) {
		Course_id = course_id;
	}
	public String getSubject_name() {
		return Subject_name;
	}
	public void setSubject_name(String subject_name) {
		Subject_name = subject_name;
	}
}
