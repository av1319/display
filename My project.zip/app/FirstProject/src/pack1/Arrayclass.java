package pack1;
import java.util.Scanner;
public class Arrayclass {

	public static void main(String[] args) {
		int n, sum = 0;
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter no. of elements");
        n = sc.nextInt();//takes size of the array and stores it in n
        int a[] = new int[n]; //declaration of the array a[]
        System.out.println("Enter all the elements:");
        for(int i = 0; i < n; i++)
        {
            a[i] = sc.nextInt();
            sum = sum + a[i];
        }
        System.out.println("Sum:"+sum);
        

	}
}
