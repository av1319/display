package pack1;

public class Function_overload {

	public static void main(String[] args) {
		int a;
		char b;
		float c;
		
		Function_overload fo=new Function_overload();
		fo.display(10);
		fo.display(20, 'A');
		fo.display(30,'B',333.33f);
		
		
	}
	public void display(int a){
		System.out.println("This is only has only one argument int a: "+a);
		}

	public void display(int a,char b){
		System.out.println("This is only has two argument int a: "+a+ " char b= "+b);
	}
	public void display(int a,char b,float c){
		
		System.out.println("This is only has 3 arguments int a: "+a+" char b= "+b+ " float c= "+c);
	}
	

}
