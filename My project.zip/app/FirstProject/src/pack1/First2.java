package pack1;
//Program to show the passing of objects as parameters
class Area_Rectangle{
	public int len,wid;
	
	public Area_Rectangle(int len,int wid){
	//Parameterized Constructor
		this.len=len;
		this.wid=wid;
		
	}
	
	
	
	
	public void Calculate(Area_Rectangle f2){
		int area=f2.len*f2.wid;//calculates area
		System.out.println("Area of rectangle is "+area);//display area
	}
	
}
public class First2 {
	public static void main(String[] args) {
		Area_Rectangle f2=new Area_Rectangle(5,12);//passing length and width value to constructor
		f2.Calculate(f2);//Passing Object as parameter
	}

}
