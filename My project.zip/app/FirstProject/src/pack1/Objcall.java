package pack1;
import java.util.Scanner;
class Passparam{
	int len,bre;
	public Passparam(int len,int bre){
		this.len=len;
		this.bre=bre;
	}
	public int area()
	{
		int area=len*bre;
		return area;
	}
}

public class Objcall {
public void display(Passparam pam){
		
		System.out.println(pam.area());
	}
	public static void main(String[] args) {
	Scanner sc= new Scanner(System.in);
	int len = sc.nextInt();
	int bre = sc.nextInt();

	Objcall ob = new Objcall();
	Passparam pa = new Passparam(len,bre);
	ob.display(pa);	
}

}
