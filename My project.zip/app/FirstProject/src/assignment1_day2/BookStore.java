package assignment1_day2;

public class BookStore {

	Book[] books;
	
	public BookStore(int size){
		books= new Book[size];
	}
	
	void init(){
		for (int i = 0; i < books.length; i++) {
			books[i]=new Book("Book "+i,"Author "+i,"ISBN "+i,i);
		}
	}
	
public void sell(String bookTitle, int numOfCopies) {
	boolean bookFound=false;
	int j;
	for ( j = 0; j < books.length; j++) {
		
		if(books[j].getBookTitle().equals(bookTitle)){
			
			if(books[j].getNumOfCopies()>=numOfCopies)
				books[j].setNumOfCopies(books[j].getNumOfCopies()-numOfCopies);
				bookFound=true;
				break;
		}
			else
			{
			bookFound=false;
			}
		}
			if(bookFound){
				
				System.out.println(books[j].getNumOfCopies()+" Books sold"+books[j].getNumOfCopies()+" IS left");
					
			}
			else{
				System.out.println("Book Not Found");
			}
			
	
}
	
public void order(String isbn, int numOfCopies) {
	boolean ordered=false;
	int j;
	for ( j = 0; j < books.length; j++) {
		
		if(books[j].getISBN().equals(isbn)){
				books[j].setNumOfCopies(books[j].getNumOfCopies()+numOfCopies);
				ordered=true;
				break;
		}
	}
			
			if(ordered){
				
				System.out.println(books[j].getBookTitle()+"is added");
				System.out.println("No of available books:"+books[j].getNumOfCopies());
					
			}
			else
			{
				System.out.println("Book Not Found");
			}
			
	
	
}

public void display(){

	for (int i = 0; i < books.length; i++) {
		books[i].display();
	}
}
}
