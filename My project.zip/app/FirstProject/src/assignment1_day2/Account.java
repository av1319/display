package assignment1_day2;
import java.util.Scanner;
public class Account //Class Account
{
	private String memberName;
	private  int accountNumber;
	private double accountBalance;
	
	
	Account() {	}//non-parametrised constructor;
	
	Account(String memberName, double accountBalance)
	{
		String num = 10000 + (int)(Math. random ()*89999) + "";
		this.memberName=memberName;
		this.accountBalance=accountBalance;
		this.accountNumber=Integer.parseInt(num);
	}
	
	public String getMemberName() {
		return memberName;
	}

	public int getAccountNumber() {
		return accountNumber;
	}

	public double getAccountBalance() {
		return accountBalance;
	}
	

	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}
	
	public void deposit(double amount)//method deposit
	{
		 accountBalance=accountBalance+amount;
	}
}

//SAVINGS ACCOUNT
class SavingAccount extends Account {
	private double interest=5,maxwithdraw_limit;
	private double minBalance=4000;
	public SavingAccount(String name,double initialBalance ,double maxwithdraw_limit) {
		super(name,initialBalance);
		this.maxwithdraw_limit = maxwithdraw_limit;
	}
	
	
	public void getbalance()
	{
		System.out.println("Account Balance:"+(super.getAccountBalance() + (super.getAccountBalance()*(interest/100) ) ) );
	}
	
	public void withdraw(double withdrawamount){
		
		if(super.getAccountBalance()>= withdrawamount){
			if(maxwithdraw_limit>withdrawamount){
				super.setAccountBalance(getAccountBalance()- withdrawamount);
				System.out.println("Amount"+withdrawamount+" withdrawn");
				System.out.println("rem balance"+super.getAccountBalance());
			}
			else {
				System.out.println("min balance reached");
			}
			System.out.println("cannot withdraw max withdraw limit");
		}
		else {
			System.out.println("insufficient balance");
		}
	}
	
}
//CURRENT ACCOUNT 
class CurrentAccount extends Account {
	int tradeLicenseNumber;

	public int getTradeLicenseNumber() {
		return tradeLicenseNumber;
	}

	public CurrentAccount(String name,double initialBalance ,int tradeLicenseNumber) {
		super( name,initialBalance);
		this.tradeLicenseNumber = tradeLicenseNumber;
	}

	public void getbalance()
	{
		System.out.println("Account Balance:"+(super.getAccountBalance()) );
	}
public void withdraw(double withdrawamount){
		
		if(super.getAccountBalance()>= withdrawamount){
			super.setAccountBalance(getAccountBalance()- withdrawamount);
			System.out.println("Amount"+withdrawamount+" withdrawn");
			System.out.println("rem balance"+super.getAccountBalance());
		}
		else  {
			System.out.println("insufficient balance");
		}
}
}


//BANK CLASS
 class Bank {
public static void main(String[] args) {
	Scanner in= new Scanner(System.in);
	int input;
	int tradeLicNo;
	int type;
	double withdraw;
	double deposit;
	String name;
	double initialBalance;
	System.out.println("Enter account holder name:");
	name=in.next();
	System.out.println("Enter initial balance");
	initialBalance=in.nextDouble();
	
	System.out.println("What type of account you want to create(Savings(1)/Current(2):");
	type=in.nextInt();
	if(type==1){
		SavingAccount s= new SavingAccount(name,initialBalance,50000);
		do {
			System.out.println("enter 1 to deposit\n2 to withdraw \n3 to display balance \n 0 to exit");
		input=in.nextInt();
		
		switch(input){
		case 1:
			System.out.println("enter amount to deposit");
			deposit=in.nextDouble();
			s.deposit(deposit);
			break;
			
		case 2: 
			System.out.println("enter amount to withdraw");
			withdraw=in.nextDouble();
			s.withdraw(withdraw);
			break;
		case 3:
			s.getbalance();
		case 0: break;
		}	
		} while (input!=0);
		
	}
	
	else if(type==2){
		System.out.println("Enter Trade licence no");
		tradeLicNo=in.nextInt();
		CurrentAccount c= new CurrentAccount(name,initialBalance,tradeLicNo);
		
		do {
			System.out.println("enter 1 to deposit\n2 to withdraw \n3 to display balance \n 0 to exit");
		input=in.nextInt();
		
		switch(input){
		case 1:
			System.out.println("enter amount to deposit");
			deposit=in.nextDouble();
			c.deposit(deposit);
			break;
			
		case 2: 
			System.out.println("enter amount to withdraw");
			withdraw=in.nextDouble();
			c.withdraw(withdraw);
			break;
		case 3:
			c.getbalance();
		case 0: break;
		}	
		} while (input!=0);
	}
	else {
		System.out.println("Enter Valid Account Type");
	}
	
	
}	
}

