package assignment1_day2;
import java.util.*;

public class Vehicle{
	int noOfWheels;
	int model;
	int noOfPassengers;
	String make;
	public Vehicle(){
		super();
	}
	
	public Vehicle(int noOfWheels, int model, int noOfPassengers, String make) {
		this.noOfWheels = noOfWheels;
		this.model = model;
		this.noOfPassengers = noOfPassengers;
		this.make = make;
	}

	
	public int getNoOfWheels() {
		return noOfWheels;
	}

	public int getModel() {
		return model;
	}

	public int getNoOfPassengers() {
		return noOfPassengers;
	}

	public String getMake() {
		return make;
	}

	
	void display(){
		System.out.println("The maker is: "+make+"\nThe model is:"+model+"\nThe number of wheels is: "+noOfWheels+"\nThe Number of Passengers/Seats: "+noOfPassengers);
	}
	
}

class Car extends Vehicle{
	int noOfDoors;
	public Car(){
		super();
	}
	public Car(int noOfDoors) {
		
		this.noOfDoors = noOfDoors;
	}

	
	
	public int getNoOfDoors() {
		return noOfDoors;
	}
	
	void display(){
		System.out.println("The maker is: "+super.getMake()+"\nThe model is:"+super.getModel()+"\nThe Number of Doors: "+noOfDoors);
	}
	
}
class Convertible extends Car{
	boolean isHoodOpen;
	
	public Convertible(boolean isHoodOpen) {
		
		this.isHoodOpen = isHoodOpen;
	}

	public boolean isHoodOpen() {
		return isHoodOpen;
	}

	

	void display(){
		if(isHoodOpen==true){
			System.out.println("The maker is: "+super.getMake()+"\nThe model is:"+super.getModel()+"\nThe Number of Doors: "+super.getNoOfDoors()+"\n The Hood is Open");
			
		}
		else{
			System.out.println("The maker is: "+super.getMake()+"\nThe model is:"+getModel()+"\nThe Number of Doors: "+getNoOfDoors()+"\n The Hood is Closed");
		}
	}
	
}
class SportCar extends Car{
	final int noOfDoors;
	
	public SportCar(){
		noOfDoors=2;
	}
	void display(){
		System.out.println("This is a sports car having "+noOfDoors+" doors only ");
	}
}


class TestVehicle{
	
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int c;
		Vehicle v;
		
		do {
			System.out.println("Enter\n1 for Vehicle \n2 for Car\n3 for Convertible\n4 for SportCar");
			c=sc.nextInt();
			switch(c){
			
			case 1:
				v= new Vehicle(41,541,4,"TATA");
				v.display();
				break;
			case 2:
				v = new Car(4);
				v.display();
				break;
			case 3:
				v= new Convertible(false);
				v.display();
				break;
			case 4:
				v= new SportCar();
				v.display();
				break;
				default:
					System.out.println("enter valid choice");
				System.exit(1);
			}
		
			
		} while (c==1||c==2||c==3||c==4);
		sc.close();
	}
}
