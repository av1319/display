package testweek1;

import java.util.Scanner;

public class Icpl {
public void match(int[]Score,int num){
	                   for(int i=0;i<(num-2);i++){
	                	if((Score[i+1] - Score[i]) == (Score[i+2] - Score[i+1]))   {
	                		Score[i+1]=Score[i+1];
	                		Score[i]=-1;
	                		Score[i+2]=-1;
	                	}
	                	else {
	                		Score[i]=Score[i];
	                	}
	                   }
	                   
	                   for (int i = 0; i < num; i++) {
						if(Score[i]!=-1){
							System.out.println(Score[i]);
						}
					}
	                   
	                   
}
}
class Test{
	
	
	public static void main(String[] args) {
		Scanner s= new Scanner(System.in);
		Icpl icpl = new Icpl();
		System.out.println("enter the no of matches");
		int num = s.nextInt();
		int Score []= new int [num];
		System.out.println("Enter The score" );
		for (int i = 0; i < num; i++) {
			Score[i]=s.nextInt();
		}
			icpl.match(Score,num);
	
	
	
	}
}