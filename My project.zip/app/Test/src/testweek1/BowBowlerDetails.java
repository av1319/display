package testweek1;

import java.util.*;

public class BowBowlerDetails {

	public void BowlerDetails(int num,String[] Details ) {
		int n = 0;
		for (int i = 0; i < num; i++) {
			int sum = 0;
			String str[] = Details[i].split("");
			int length = str.length;

			for (int j = 0; j < length; j++) {
				int a = Integer.parseInt(str[j]);
				sum += a;
			}
			double average = sum / length;
			if (average >= 5.0) {

				n++;
			}
		}

		System.out.println("Output: "+n);
	}

}

class TestBowler {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		BowBowlerDetails bd = new BowBowlerDetails();
		System.out.println("enter the no of bowlers");
		int num = s.nextInt();
		String bowDetails[] = new String[num];
		System.out.println("Enter The details of every bowler ");
		for (int i = 0; i < num; i++) {
			bowDetails[i] = s.next();
		}System.out.print("Input 1: "+num);
		System.out.print("\nInput 2: ");
		System.out.print("{");
		for (int i = 0; i < num; i++) {
			
			System.out.print(bowDetails[i]);
			if ((i + 1) != num) {
				System.out.print(",");
			}

		}
		System.out.println("}");
		bd.BowlerDetails(num,bowDetails);
s.close();
	}
}