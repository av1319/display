package concept;

public class Equals {
String name;
int marks;
public Equals(String name, int marks) {
	super();
	this.name = name;
	this.marks = marks;
}


void display(){
	
	System.out.println("name"+name+"\nMarks"+marks);
}
public static void main(String[] args) {
	Equals e= new Equals("abc",100);
	Equals e1=new Equals("abc",100);
	
	System.out.println(e.equals(e1));
}
boolean equals (Equals eq){
	
	if(name==eq.name &&  marks==eq.marks)
	return true ;
	else
		return false;
}
}
