
package concept;


public class ExceptionHandling {

	public static void main(String[] args) {
		int n;
		try{
			//n=10/0;
			/*String s= null;
			System.out.println(s.length());*/
			int []arr=new int[4];
			arr[6]=123;
			
		}
		catch(ArithmeticException e){
		System.out.println("exception occured");	
		}
		catch(NullPointerException e){
			System.out.println("exception occured");	
			}
		catch(ArrayIndexOutOfBoundsException e){
			System.out.println("array exception occured");	
			}
		finally{
			
		}
	}
	
}
