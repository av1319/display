package concept;

import java.util.*;

public class ArrayListDemo {
	
	
	
public static void main(String[] args) {
	List<Student> list= new ArrayList();
	Scanner s= new Scanner(System.in);
	int c;
	Student stud;
	do {
		System.out.println("Enter Student id");
		int id=s.nextInt();
		System.out.println("Enter Student name");
		String name=s.next();
		stud= new Student(id,name);
		list.add(stud);
		System.out.println("Enter 1 to add students press 0 to exit");
		c=s.nextInt();
	} while (c==1);
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/*List<String > li1= new ArrayList();
	System.out.println("this is Integer array list");
	li.add(10);
	li.add(10);
	li.add(32);
	li.add(35);
	System.out.println(li);
	li.remove(2);
	System.out.println(li);*/
	/*System.out.println("this is String array list");
	li1.add("hello");
	li1.add("Bye");
	li1.add("Hi");
	li1.add("good");
	System.out.println(li);
	li.remove(2);
	System.out.println(li);
	li.remove(2);
	System.out.println(li);
	li.remove(1);
	System.out.println(li);
	li.remove(0);
	System.out.println(li);*/
	
	
	
}
}
