package concept;

import java.util.*;

public class StackImplementation {
	Scanner s = new Scanner(System.in);
	int size = -1;

	static int arr[];

	void push() {

		if (size == 9) {
			System.out.println("Stack is full");
		} else {
			System.out.println("enter");
			int a = s.nextInt();
			size++;
			arr[size] = a;
		}
	}

	void pop() {
		if (size == -1) {
			System.out.println("Stack is empty");
		} else {

			size--;

		}

	}

	void display() {
		for (int i = size; i >= 0; i--) {
			System.out.print(arr[i]+"\n");
		}
	}

	public static void main(String[] args) {
		StackImplementation si = new StackImplementation();
		arr = new int[10];
		int c;
		do {
			System.out.println("1 to push \n2 to pop\n3 to display");
			Scanner s = new Scanner(System.in);
			 c = s.nextInt();

			switch (c) {
			case 1:
				si.push();
				break;
			case 2:
				si.pop();
				break;
			case 3:
				si.display();
				break;
			default:
				System.out.println("invalid choice");
				System.exit(1);
			}

		} while (c==1||c==2||c==3);

	}

}
