package concept;

public class WrapperClass {
public static void main(String[] args) {
	int a=10;
	Integer in= new Integer(a);
	int b= in.intValue();
	
}
}
