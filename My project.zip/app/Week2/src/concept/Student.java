package concept;

import java.util.*;

class Test implements Comparable<Student> {


	
	public int compareTo(Student stud) {
		
		if(==stud.id)  
		      return 0;  
		   else if(this.id>stud.id)  
		      return 1;  
		   else  
		      return -1;  
	}
	

}
public class Student{
int id;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}

String name;
static List  <Student> list= new ArrayList();

public Student(){
	
}
public Student(int id, String name) {
	
	this.id = id;
	this.name = name;
}
public String toString(){
	
	return "The Student id "+id+" Student Name "+name;
}

public void display(List<Student> list){
	for (int i = 0; i <list.size() ; i++) {
		System.out.println(list.get(i));
		
	}
}

public void update(int id){
	Scanner sc= new Scanner(System.in);
	System.out.println("Before Update the list is: "+list);
	Iterator<Student>its=list.iterator();
	while (its.hasNext()){
		Student stud= its.next();
		if(id==stud.id){
			System.out.println("update name");
			String update=sc.next();
			stud.name=update;
			stud.display(list);
		}
			
	}
	
	
	
}

public static void main(String[] args) {
	Scanner s= new Scanner(System.in);
	
	Student stud=new Student();
	int c;
	do {
		System.out.println("Enter \n1 to add students\n2 to delete\n3 to display \n4 to update record\n5 for sorted display  press 0 to exit");
		c=s.nextInt();
		switch(c){
		case 1:
			System.out.println("Enter Student id");
			int id=s.nextInt();
			System.out.println("Enter Student name");
			String name=s.next();
			stud= new Student(id,name);
			list.add(stud);
			break;
		case 2:
			System.out.println("Enter Student id to remove its data");
			int index=s.nextInt();
			for (int i = 0; i < list.size(); i++) {
				Student s2= list.get(i);
				if(index==s2.id){
					list.remove(i);
				}
			}
		    stud.display(list);
		    break;
		case 3: 
			stud.display(list);
			break;
		case 4:
			System.out.println("Enter the students id to update data");
			int up=s.nextInt();
			stud.update(up);
			break;
		case 5: 
				System.out.println("Unsorted");
				for (int i = 0; i < list.size(); i++)
					System.out.println(list.get(i));
				Collections.sort(list);�
				System.out.println("\nSorted by rollno");
				for (int i = 0; i < list.size(); i++)
					System.out.println(list.get(i));
			
			
		}
		
		
	} while (c==1||c==2||c==3);
	//
	//System.out.print(list);
	
}
}

