package com.nucleus.dao;

import java.util.ArrayList;
import java.util.List;
import java.io.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.nucleus.connection.CreateConnection;
import com.nucleus.domain.CustomerM;
import com.nucleus.errorlog.ErrorLog;
import com.nucleus.validation.ValidationClass;

public class CustomerDAOImpl implements CustomerDAO {
	PreparedStatement preparedStatement = null;
	BufferedReader bufferedReader = null;
	ErrorLog errorLog = new ErrorLog();
	String line;
	CreateConnection createConnection = new CreateConnection();
	Connection conn = createConnection.ConnectionClass();
	// readfromfile method return type list of customers
	static int count = 1;

	public void readFromFile(String loc, int rej) {

		FileReader fileReader = null;
		BufferedReader bufferedReader = null;
		CustomerM customerM = new CustomerM();
		ValidationClass validationClass = new ValidationClass();

		
		int errorCount = 0;

		try {
			fileReader = new FileReader(loc);
			bufferedReader = new BufferedReader(fileReader);
			String str1 = bufferedReader.readLine();
			while (str1 != null) {
				line = str1;
				String str[] = str1.split("~", -1);

				// Validation CustomerCode
				if (validationClass.nullCheck(str[0])
						&& (str[0].length() <= 10)) {
					customerM.setCustomerCode(str[0]);

				} else {

					errorCount++;
				}

				// Validation CustomrName
				int len = str[1].length();
				if (validationClass.customerNameValidation(str[1])
						&& (len <= 30)) {

					customerM.setCustomerName(str[1]);
				} else {

					errorCount++;
				}

				// Validation CustomerAddress 1
				len = str[2].length();
				if (validationClass.nullCheck(str[2]) && (len <= 100)) {
					customerM.setCustomerAdd1(str[2]);

				} else {

					errorCount++;
				}

				// Validation CustomerAddress 2
				if (str[3].length() <= 100) {

					customerM.setCustomerAdd2(str[3]);
				} else {

					errorCount++;
				}

				// Validation CustomerPinCode
				len = str[4].length();
				if (validationClass.fieldLengthValidation((Long.parseLong(str[4]))) && len <= 6) {

					customerM.setCustomerPinCode(Long.parseLong(str[4]));
				} else {

					errorCount++;
				}

				// Validation CustomerEmail Address
				len = str[5].length();
				if (validationClass.emailValidation(str[5]) && (len <= 100)) {

					customerM.setEmailAdd(str[5]);
				} else {

					errorCount++;
				}

				// Validation Customer Contact Number
				if (str[6].length() <= 20) {

					customerM.setContact_Number(Long.parseLong(str[6]));
				} else {

					errorCount++;
				}

				// Validation PrimaryContactPerson
				len = str[7].length();
				if (validationClass.nullCheck(str[7]) && (len <= 100)) {
					customerM.setPrimaryContactPerson(str[7]);

				} else {

					errorCount++;
				}

				// Validation Record Status
				len = str[8].length();
				if (validationClass.recordStatusValidation(str[8])
						&& (len <= 1)) {

					customerM.setRecordStatus(str[8]);
				} else {

					errorCount++;
				}
				// ////////////////////////////////////////////////////
				// Validation Flag
				len = str[9].length();
				if (validationClass.flagValidation(str[9]) && (len <= 1)) {

					customerM.setFlag(str[9]);
				} else {

					errorCount++;
				}

				// Validation Create Date
				if (validationClass.nullCheck(str[10])) {
					customerM.setCreateDate(str[10]);

				} else {

					errorCount++;
				}

				// Validation Create BY
				len = str[11].length();
				if (validationClass.nullCheck(str[11]) && (len <= 30)) {
					customerM.setCreatedBy(str[11]);

				} else {

					errorCount++;
				}
				// *********************************
				customerM.setModifiedDate(str[12]);
				// -*******************************

				// Validation Modified BY
				len = str[13].length();
				if (len <= 30) {

					customerM.setModifiedBy(str[13]);
				} else {

					errorCount++;
				}
				// *****************************************
				customerM.setAuthorisedDate(str[14]);
				// **************************************************

				// Validation Authorised BY
				len = str[15].length();
				if (str[15].length() <= 30) {

					customerM.setAuthorisedBy(str[15]);
				} else {

					errorCount++;
				}

				// Check for Rejection Level Inputs

				if (errorCount == 0) {
					insertIntoDatabase(customerM);
					str1 = bufferedReader.readLine();

				}
				// when Atleast one validation is
				else {
					if (rej == 1) {

						errorLog.saveToFile(str1);
						str1 = bufferedReader.readLine();
						errorCount = 0;
					} else {
						System.out.println("Error Found in file level rejection Whole file will be rejected and saved in error log files");
						errorLog.copyfile(loc);// copies file into another file
						PreparedStatement preparedStatement;
						try {
							preparedStatement = conn.prepareStatement("delete from seq1234");
							preparedStatement.executeUpdate();

						} catch (SQLException e) {
							e.printStackTrace();
						}
						System.exit(0);

					}

				}
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		} catch (Exception e) {

			e.printStackTrace();
		}

		finally {

			try {

				bufferedReader.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}

	public void insertIntoDatabase(CustomerM customerM) {
		// Function to insert data in database

		try {

			preparedStatement = conn.prepareStatement("insert into seq1234 values(myseq121.nextval,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
			preparedStatement.setString(1, customerM.getCustomerCode());
			preparedStatement.setString(2, customerM.getCustomerName());
			preparedStatement.setString(3, customerM.getCustomerAdd1());
			preparedStatement.setString(4, customerM.getCustomerAdd2());
			preparedStatement.setLong(5, customerM.getCustomerPinCode());
			preparedStatement.setString(6, customerM.getEmailAdd());
			preparedStatement.setLong(7, customerM.getContact_Number());
			preparedStatement.setString(8, customerM.getPrimaryContactPerson());
			preparedStatement.setString(9, customerM.getRecordStatus());
			preparedStatement.setString(10, customerM.getFlag());
			preparedStatement.setString(11, customerM.getCreateDate());
			preparedStatement.setString(12, customerM.getCreatedBy());
			preparedStatement.setString(13, customerM.getModifiedDate());
			preparedStatement.setString(14, customerM.getModifiedBy());
			preparedStatement.setString(15, customerM.getAuthorisedDate());
			preparedStatement.setString(16, customerM.getAuthorisedBy());
			preparedStatement.executeUpdate();

			System.out.print("line" + count++);
			System.out.print(" Saved\n");

		} catch (SQLException e) {
			errorLog.saveToFile(line);
			e.printStackTrace();
		}

	}

}
