package credentials;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class CreateConnection {

	public Connection ConnectionClass() {
		Connection conn = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection(
					"jdbc:oracle:thin:@10.1.50.198:1521:orcl", "sh", "sh");
		} catch (ClassNotFoundException e1) {

			e1.printStackTrace();
		} catch (SQLException e) {

			e.printStackTrace();
		}

		return conn;

	}

}
