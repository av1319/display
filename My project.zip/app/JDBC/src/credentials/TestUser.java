package credentials;

import java.sql.Connection;
import java.util.*;

public class TestUser {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int ch;
		String email,uid,pass;
		SignupSignin sin=new SignupSignin();
		CreateConnection createConnection = new CreateConnection();
		Connection conn = createConnection.ConnectionClass();
		do {
			System.out.println("Enter \n1 to signup \n2 to Signin");
			ch = s.nextInt();
			switch(ch){
			case 1 :
				System.out.println("Enter the email");
			 email = s.next();	
				System.out.println("Enter the user id ");
				 uid= s.next();
				System.out.println("Enter the password ");
				 pass= s.next();
				sin.SignUp(email,uid,pass);
				break;
			case 2:
				System.out.println("Enter the user id ");
				 uid= s.next();
				System.out.println("Enter the password ");
				pass= s.next();
				sin.SignIn (uid , pass);	
				break;
				default:
					System.out.println("invalid choice ");
			}
			
			
		}while(ch==1||ch==2);

		s.close();
	}
}
