package credentials;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import jdbconcept.CreateConnection;

public class SignupSignin {
	Scanner s = new Scanner(System.in);

    ResultSet resultSet= null;
    PreparedStatement pst1=null;
    CreateConnection createConnection = new CreateConnection();
	Connection conn = createConnection.ConnectionClass();
	
	void SignUp(String email,String userid,String pass){
		
		try {
			
			/*CreateConnection createConnection=new CreateConnection();	
		    Connection conn= createConnection.ConnectionClass();*/
			
			pst1 = conn.prepareStatement("insert into RegisterAkash values (?,?,?)");
			
			pst1.setString(3,email);
			pst1.setString(1,userid);
			pst1.setString(2,pass);
			pst1.executeUpdate();
			System.out.println("*************Sign up Completed************");
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	
		
	}
	
	void SignIn(String uid,String pass){
		
		try {
			/*CreateConnection createConnection=new CreateConnection();	
		    Connection conn= createConnection.ConnectionClass();*/
			pst1 = conn.prepareStatement("Select * from RegisterAkash where userid=? and password=?");
			pst1.setString(1,uid);
			pst1.setString(2,pass);
			
			
			resultSet = pst1.executeQuery();
			
			
			if(resultSet.next())
			{
			
					System.out.println("Welcome User");
			}		
			
					else{
						System.out.println("Invalid");
						
						}
				
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		finally{
			try {
				conn.close();
				pst1.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	
}
