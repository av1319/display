package jdbcdemo;

import java.sql.*;

public class TestSample {
public static void main(String[] args) {
	Connection conn=null;
	try {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		conn=DriverManager.getConnection("jdbc:oracle:thin:@10.1.50.198:1521:orcl","sh","sh");
		
		PreparedStatement  pst1= conn.prepareStatement("insert into book121 values (?,?,?)");
		
		pst1.setInt(1,127);
		pst1.setString(2,"Mystery7");
		pst1.setFloat(3,380.0f);
		
		pst1.executeUpdate();
		
		
		
		
		
		
		PreparedStatement  pst= conn.prepareStatement("Select * from book121");
		//pst.setString(1, "Mystery2");
		ResultSet resultSet = pst.executeQuery();
		
		while(resultSet.next()){
			int book_id= resultSet.getInt(1);
			String book_title= resultSet.getString(2);
			float book_price= resultSet.getFloat(3);
			System.out.println("The Book id is:"+book_id+"  The Book title:"+book_title+"  The Book Price"+book_price);
			
		}
	} catch (ClassNotFoundException e) {
	
		e.printStackTrace();
	} catch (SQLException e) {
		
		e.printStackTrace();
	}
	finally{
		try {
			conn.close();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	}
}
}
