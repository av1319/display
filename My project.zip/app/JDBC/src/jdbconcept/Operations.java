package jdbconcept;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class Operations {
	Scanner s = new Scanner(System.in);
	CreateConnection createConnection=new CreateConnection();	
    Connection conn= createConnection.ConnectionClass();
    ResultSet resultSet= null;
    PreparedStatement pst1=null;
	
	void insert(){
		
	try {
		pst1 = conn.prepareStatement("insert into book121 values (?,?,?)");
		System.out.println("Enter the id to insert");
		int id= s.nextInt();
		System.out.println("Enter the name to insert");
		String name= s.next();
				System.out.println("Enter the price to insert");
				float price = s.nextFloat();
		pst1.setInt(1,id);
		pst1.setString(2,name);
		pst1.setFloat(3,price);
		pst1.executeUpdate();
		
		
	} catch (SQLException e) {
		e.printStackTrace();
	}
	finally{
		try {
			conn.close();
			pst1.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
		
		
		
	}
	
	
	void display(){
		
		
		try {
			pst1 = conn.prepareStatement("Select * from book121 where bid =? ");
			resultSet = pst1.executeQuery();
			
			while(resultSet.next()){
				int book_id= resultSet.getInt(1);
				String book_title= resultSet.getString(2);
				float book_price= resultSet.getFloat(3);
				System.out.println("The Book id is:"+book_id+"  The Book title:"+book_title+"  The Book Price"+book_price);
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		finally{
			try {
				conn.close();
				pst1.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	
	}
	
void delete(){
	try {
		System.out.println("Enter the id to delete");
		int id= s.nextInt();
		pst1 = conn.prepareStatement("delete from book121 where bid=?");
		pst1.setInt(1,id);
		pst1.executeUpdate();
		System.out.println("id "+id+"Deleted");
		
	} catch (SQLException e) {
		
		e.printStackTrace();
	}
	finally{
		try {
			conn.close();
			pst1.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
		
		
	}
void update(){
	
	try {
		System.out.println("Enter the id to update");
		int id= s.nextInt();
		System.out.println("Enter the the new name");
		String name= s.next();
		pst1 = conn.prepareStatement("update book121 set btitle=? where bid=?");
/*		UPDATE customers
		SET first_name = 'Judy'
		WHERE customer_id = 8000;*/
		pst1.setString(1,name);
		pst1.setInt(2,id);
		pst1.executeUpdate();
		System.out.println("---------Updated----------");
		
		
	} catch (SQLException e) {
		
		e.printStackTrace();
	}
	finally{
		try {
			conn.close();
			pst1.close();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	}
	
}
	
}
