package jdbconcept;

import java.sql.Connection;
import java.util.*;

public class TestUser {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int ch;
		CreateConnection createConnection = new CreateConnection();
		Connection conn = createConnection.ConnectionClass();
		Operations oper = null;

		do {
			System.out
					.println("Enter 1 to insert \n2 to display\n3 to delete \n4 to update");
			ch = s.nextInt();
			switch (ch) {
			case 1:
				oper = new Operations();
				oper.insert();
				break;
			case 2:
				oper = new Operations();
				oper.display();
				break;
			case 3:
				oper = new Operations();
				oper.delete();
				break;
			case 4:
				oper = new Operations();
				oper.update();
				break;
			default:System.out.println("You have entered a wrong choice");
				break;
			}

		} while (ch == 1||ch==2||ch==3||ch==4);
		s.close();
	}
}
