package week3;

public class DaemonThread extends Thread
{
    public void run()
    { 
    	
    	Thread Th= Thread.currentThread();
    	System.out.println(Th.getName());
    	for (int i = 1; i <= 5; i++) {
			System.out.println("Child Thread"+i);
		}
        if(Th.isDaemon())
        { 
            System.out.println("Daemon thread"); 
        } 
         
        else
        { 
            System.out.println("Normal thread"); 
        } 
    } 
     
    public static void main(String[] args)
    { 
        DaemonThread t1 = new DaemonThread();
        Thread Th1= Thread.currentThread();
    	System.out.println(Th1.getName());
    	System.out.println("Thread1 "+t1.getPriority());
    	System.out.println("Main "+Th1.getPriority());
    
       
        t1.setDaemon(true);
             
        
        t1.start(); 
     
       
        for (int i = 1; i <= 5; i++) {
			System.out.println("Main Thread"+i);
		}
    
    
         
    } 
}