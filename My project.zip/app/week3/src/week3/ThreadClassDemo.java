package week3;

public class ThreadClassDemo {

	public static void main(String[] args) {
		
		ChildThread childThread= new ChildThread();
		Thread thread= new Thread(childThread);
		Thread th = Thread.currentThread();
		
		
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		}
		System.out.println(th.getName());
		th.setName("MAIN");
		thread.start();
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		for (int i = 1; i <= 5; i++) {
			System.out.println("Main Thread"+i);
		}

	}

}


class ChildThread implements Runnable{

	
	public void run() {
		
		
		Thread th1 = Thread.currentThread();
		th1.setName("CHILD");
        System.out.println(th1.getName());
		for (int i = 1; i <= 5; i++) {
			System.out.println("Child Thread"+i);
		}
		
	}
	
	
	
	
	
	
	
}
