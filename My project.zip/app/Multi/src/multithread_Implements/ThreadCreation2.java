package multithread_Implements;

public class ThreadCreation2 implements Runnable 
{
public void run()
{
	for(int i=0;i<5;i++)
		System.out.println ("child thread is running");
	}
}
