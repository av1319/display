package multithread_Implements;

public class Main {
	public static void  main(String args[])
	{
		ThreadCreation2 threadCreation2=new ThreadCreation2();  
		Thread thread=new Thread(threadCreation2);
		thread.start();
		
		for(int i=0;i<5;i++)
		System.out.println("main thread is running  ");
		
	}
		
	}
