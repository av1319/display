package join;

public class Main 
{
public static void main(String args[])
{
TestJoin testjoin=new TestJoin();
Thread thread=new Thread(testjoin);
thread.start();
//thread.start(); caused Exception
try {
	thread.join(3000);
} catch (InterruptedException e) {
	
	e.printStackTrace();
}
for(int i=0;i<10;i++)
{
	System.out.println("Main"+i);
}
	
}
}
