package getsetname;

public class ThreadName implements Runnable 
{
public void run()
{
	System.out.println("CHild Thread");

	}
	
}


