package getsetname;

public class Main {
	public static void main(String argsp[])
	{
		ThreadName threadName=new ThreadName();
		Thread thread=new Thread(threadName);
		System.out.println("Thread Name"+thread.getName());
		thread.setName("New Thread");
		System.out.println("Thread changed Name"+thread.getName());
		thread.start();
		
	}

}
