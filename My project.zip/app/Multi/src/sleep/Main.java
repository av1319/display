package sleep;

public class Main 
{
	public static void main(String args[])  
	{
		
		
		ThreadSleep threadSleep=new ThreadSleep();
		Thread thread=new Thread(threadSleep);
		thread.start();
		for(int i=0;i<10;i++)
		{
			System.out.println("Main"+i);
		}
		
	}

}
