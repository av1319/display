package multithread_extends;

public class Main {
	public static void  main(String args[])
	{
		ThreadCreation1 threadCreation1=new ThreadCreation1();  
		threadCreation1.start();
		for(int i=0;i<5;i++)
		System.out.println("main thread is running  ");
		
	}
		
	}


