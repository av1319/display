package multithread_extends;

public class ThreadCreation1 extends  Thread 
{

	public void run()
	{
		for(int i=0;i<5;i++)
		System.out.println ("child thread is running");
	}
}